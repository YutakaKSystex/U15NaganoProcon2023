﻿//U15長野プログラミングコンテスト2023実行委員会
using CHaser;
using System;

namespace ProConProgram
{
    class Program
    {
        #region ローカル定数・設定情報
        const int TopLeft = 0;
        const int Up = 1;
        const int TopRight = 2;
        const int Left = 3;
        const int Center = 4;
        const int Right = 5;
        const int BottomLeft = 6;
        const int Down = 7;
        const int BottomRight = 8;
        const int Player = 1;
        const int Block = 2;
        const int Item = 3;
        const int Nothing = 0;
        //接続用インスタンス
        private static Client Target = Client.Create();
        private Random random = new Random();
        #endregion

        static void Main(string[] args)
        {
            //使用するマップとプレイヤー名の指定
            Target.Name = "自分";
            Target.Room_Name = "01_practice";

            #region 初期処理等
            int direction = 0;
            int[] value = new int[9];
            int[] result = new int[9];
            Target.Connect_Server();
            #endregion

            while (true)
            {
                #region GetReady命令
                // 自分のターンが来たら、GetReadyの命令が実行されます。
                // GetReadyの命令が実行されると、valueという配列に自分の周辺情報が代入されます。
                // この命令(GetReady)は毎ターン、はじめに必ず実行しなければなりませんので、絶対に消さないでください。
                value = Target.GetReady();
                #endregion






            }
        }
    }
}